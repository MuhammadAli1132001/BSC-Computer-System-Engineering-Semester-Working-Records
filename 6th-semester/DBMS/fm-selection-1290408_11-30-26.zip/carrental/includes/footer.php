
<script src="https://apps.elfsight.com/p/platform.js" defer></script>
<div class="elfsight-app-920a61b1-88cb-4081-8f9e-f3f591da3c08"></div>

<footer id="footer">
  <div class="container">
    <div class="copyright">
      &copy; Copyright <strong>LemoDxb Car Rental Company</strong>. All Rights Reserved
    </div>
  </div>
</footer>